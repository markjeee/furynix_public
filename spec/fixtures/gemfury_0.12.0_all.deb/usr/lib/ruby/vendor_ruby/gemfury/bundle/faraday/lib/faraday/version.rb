# frozen_string_literal: true

module Faraday
  VERSION = '1.4.3'
end
