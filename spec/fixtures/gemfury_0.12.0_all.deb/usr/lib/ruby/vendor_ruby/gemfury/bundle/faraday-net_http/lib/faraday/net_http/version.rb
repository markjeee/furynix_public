# frozen_string_literal: true

module Faraday
  module NetHttp
    VERSION = '1.0.1'
  end
end
