# Adding require paths to load path (empty if no gems is needed)

require 'rubygems'

ENV['GEM_HOME'] = ''
ENV['GEM_PATH'] = ''
Gem.clear_paths

# == Gem: faraday-em_http, version: 1.0.0
$:.unshift File.expand_path('../../faraday-em_http/lib', __FILE__)

# == Gem: faraday-em_synchrony, version: 1.0.0
$:.unshift File.expand_path('../../faraday-em_synchrony/lib', __FILE__)

# == Gem: faraday-excon, version: 1.1.0
$:.unshift File.expand_path('../../faraday-excon/lib', __FILE__)

# == Gem: faraday-net_http, version: 1.0.1
$:.unshift File.expand_path('../../faraday-net_http/lib', __FILE__)

# == Gem: faraday-net_http_persistent, version: 1.1.0
$:.unshift File.expand_path('../../faraday-net_http_persistent/lib', __FILE__)

# == Gem: multipart-post, version: 2.1.1
$:.unshift File.expand_path('../../multipart-post/lib', __FILE__)

# == Gem: ruby2_keywords, version: 0.0.4
$:.unshift File.expand_path('../../ruby2_keywords/lib', __FILE__)

# == Gem: faraday, version: 1.4.3
$:.unshift File.expand_path('../../faraday/lib', __FILE__)
$:.unshift File.expand_path('../../faraday/spec/external_adapters', __FILE__)

# == Gem: highline, version: 2.0.3
$:.unshift File.expand_path('../../highline/lib', __FILE__)

# == Gem: multi_json, version: 1.15.0
$:.unshift File.expand_path('../../multi_json/lib', __FILE__)

# == Gem: netrc, version: 0.11.0
$:.unshift File.expand_path('../../netrc/lib', __FILE__)

# == Gem: progressbar, version: 1.11.0
$:.unshift File.expand_path('../../progressbar/lib', __FILE__)

# == Gem: thor, version: 1.0.1
$:.unshift File.expand_path('../../thor/lib', __FILE__)


