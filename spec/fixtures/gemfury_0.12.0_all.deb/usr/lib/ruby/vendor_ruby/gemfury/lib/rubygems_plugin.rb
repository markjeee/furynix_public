require 'rubygems/command_manager'
Gem::CommandManager.instance.register_command :fury
