class Thor
  VERSION = "1.0.1"
end
