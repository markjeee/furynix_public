# frozen_string_literal: true

module Faraday
  module NetHttpPersistent
    VERSION = "1.1.0"
  end
end
