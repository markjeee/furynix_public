require 'ruby-progressbar/refinements/enumerator'
