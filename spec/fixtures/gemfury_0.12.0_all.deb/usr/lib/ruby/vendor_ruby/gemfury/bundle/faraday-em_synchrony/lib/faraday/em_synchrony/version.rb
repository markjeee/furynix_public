# frozen_string_literal: true

module Faraday
  module EmSynchrony
    VERSION = '1.0.0'
  end
end
