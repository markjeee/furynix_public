# Load Gemfury rakefile extensions
load "gemfury/tasks/release.rake"