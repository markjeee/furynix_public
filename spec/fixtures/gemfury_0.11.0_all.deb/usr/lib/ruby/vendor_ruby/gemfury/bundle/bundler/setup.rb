# Adding require paths to load path (empty if no gems is needed)

require 'rubygems'

ENV['GEM_HOME'] = ''
ENV['GEM_PATH'] = ''
Gem.clear_paths

# == Gem: multipart-post, version: 2.1.1
$:.unshift File.expand_path('../../multipart-post/lib', __FILE__)

# == Gem: faraday, version: 0.15.4
$:.unshift File.expand_path('../../faraday/lib', __FILE__)

# == Gem: highline, version: 2.0.3
$:.unshift File.expand_path('../../highline/lib', __FILE__)

# == Gem: multi_json, version: 1.14.1
$:.unshift File.expand_path('../../multi_json/lib', __FILE__)

# == Gem: netrc, version: 0.11.0
$:.unshift File.expand_path('../../netrc/lib', __FILE__)

# == Gem: progressbar, version: 1.10.1
$:.unshift File.expand_path('../../progressbar/lib', __FILE__)

# == Gem: thor, version: 0.20.3
$:.unshift File.expand_path('../../thor/lib', __FILE__)


