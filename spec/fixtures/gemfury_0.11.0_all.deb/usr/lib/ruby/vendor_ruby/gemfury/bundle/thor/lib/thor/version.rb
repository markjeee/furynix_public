class Thor
  VERSION = "0.20.3"
end
